var gulp = require('gulp');  
var gulp = require('gulp');	 
var browserSync = require('browser-sync').create();
var reload = browserSync.reload;
var plumber = require('gulp-plumber');
var rename = require('gulp-rename');
var sourcemaps = require('gulp-sourcemaps');
var sass = require('gulp-sass');
var uglify = require('gulp-uglify');
var concat = require('gulp-concat');
var minifyHtml = require('gulp-minify-html');
var imageMin = require('gulp-imagemin');
var iconfont = require('gulp-iconfont');
var notify = require('gulp-notify');
var pug = require('gulp-pug');
var size = require('gulp-filesize');
var gutil = require('gulp-util');
var merge = require('merge-stream');
var cleanCSS = require('gulp-clean-css');
var del = require('del');
var order = require("gulp-order");
var consolidate = require('gulp-consolidate');
var order = require("gulp-order");


var paths = {
	src: {		
        components : {
            bootstrapFonts : 'bower_components/bootstrap-sass/assets/fonts/bootstrap/',
            bootstrapJS : 'bower_components/bootstrap-sass/assets/javascripts/',
            bootstrapStyle : 'bower_components/bootstrap-sass/assets/style/bootstrap/',
            jquery : 'bower_components/jquery/dist/',
            animate : 'bower_components/animatewithsass/',
            mobileDetect : 'bower_components/mobile-detect/'
        },
		favicon : 'src/favicon/',
		images : 'src/images/',
		fonts : 'src/fonts/',
		svg : 'src/svg/', 
		js : 'src/js/',
		sass : 'src/sass/',
		jade : 'src/jade/',
		data : 'src/data/',
	},
	dist: {
		root : 'dist/',
		images : 'dist/images/',
		js : 'dist/js/',
		fonts: 'dist/fonts/',
		css: 'dist/css/'
	}
}



gulp.task('clean-js', function () {
    return del([
       paths.dist.js + '/*'
    ]);
});
 
gulp.task('clean-css', function () {
    return del([
        paths.dist.css + '/*'
    ]);
});


//gulp task to copy fonts
gulp.task('copy-fonts', function() { 
    return gulp.src([
            paths.src.fonts + '**/*', 
        	paths.src.components.bootstrapFonts + '*'
        ]) 
        .pipe(gulp.dest(paths.dist.fonts))
        .pipe(notify({message: 'TASK: "copy-fonts" Completed!', onLast: true }));
});



//optimize images
gulp.task('images',function(){
    gulp.src(paths.src.images+'**/*')
        .pipe(plumber({
            handleError: function (err) {
                console.log(err);
                this.emit('end');
            }
        }))
    	.pipe(imageMin())
        .pipe(size())
        .pipe(gulp.dest(paths.dist.images))
        //.pipe(reload())
        .pipe(notify({message: 'TASK: "images" Completed!', onLast: true }));
});



//Convert svg to fonts


gulp.task('iconfont', function () {
   return gulp.src(paths.src.svg +'**/*.svg')

        .pipe(iconfont({
            fontName: 'fciconfont',
            formats: ['ttf', 'eot', 'woff', 'woff2'],
            appendCodepoints: true,
            appendUnicode: false,
            normalize: true,
            fontHeight: 1000,
            centerHorizontally: true
        }))
        .on('glyphs', function (glyphs, options) {
            gulp.src(paths.src.svg + 'fciconfont.scss')
                .pipe(consolidate('underscore', {
                    glyphs: glyphs,
                    fontName: options.fontName,
                    fontDate: new Date().getTime()
                }))
                .pipe(gulp.dest(paths.src.fonts + 'fciconfont'));
            gulp.src(paths.src.svg + '/index.html')
                .pipe(consolidate('underscore', {
                    glyphs: glyphs,
                    fontName: options.fontName
                }))
                .pipe(gulp.dest(paths.src.fonts+'fciconfont'));
        })
        .pipe(gulp.dest(paths.src.fonts+'fciconfont'));
});




// Pug to html
gulp.task('jade',function(){
    gulp.src([paths.src.jade + '*.pug'])
        .pipe(plumber({
            handleError: function (err) {
                console.log(err);
                this.emit('end');
            }
        }))
        .pipe(pug({
                pretty: true}
            ))
        //.pipe(minifyHtml())
        .pipe(size())
        .pipe(gulp.dest(paths.dist.root))
        // .pipe(reload())
        .pipe(notify({message: 'TASK: "jade" Completed!', onLast: true }));
});


/*bundle all the vendors js and add in one */
gulp.task('vendorsJS', function(){
	var vendorsJSStream = gulp.src([
		paths.src.components.jquery+'jquery.js',
        paths.src.js+'/vendors/modernizr-custom.js',
		paths.src.components.bootstrapJS+'bootstrap.js',
        paths.src.components.mobileDetect+'mobile-detect.js',
        paths.src.js+'/vendors/jquery.resize.js',
        ])
	;

	var vendorsMergedJSStream = merge(vendorsJSStream)
        .pipe(concat('vendors.js'))
        //.pipe(uglify({mangle: false}))
        .pipe(size())
        .pipe(gulp.dest(paths.dist.js))
        .pipe(notify({message: 'TASK: "vendorsJS" Completed!', onLast: true }));
    return vendorsMergedJSStream;
});



//bundle all the custom js in one 
gulp.task('customJS', function(){
	var customJSStream = gulp.src([
    		paths.src.js+'scripts.js'
        ])
	;

	var customMergedJSStream = merge(customJSStream)
        .pipe(concat('theme.js'))
        //.pipe(uglify({mangle: false}))
        .pipe(size())
        .pipe(gulp.dest(paths.dist.js))
        .pipe(notify({message: 'TASK: "customJS" Completed!', onLast: true }));
    return customMergedJSStream;
});

//Vendors Style.css from all vendors CSS and SCSS
gulp.task('vendorStyle', function() {
	var cssVendorsStream = gulp.src([
    		// paths.src.components+'flexslider/flexslider.css',
      //       paths.src.components+'select2-master/dist/css/select2.css'
        ])
	;

    var mergedStream = merge(/*lessVendorsStream,*//* scssVendorsStream,*/ cssVendorsStream)
        .pipe(concat('vendors.css'))
        //.pipe(cleanCSS())
        .pipe(size())
        .pipe(gulp.dest(paths.dist.css))
        .pipe(notify({message: 'TASK: "vendorStyle" Completed!', onLast: true }));
    return mergedStream;
});


//Theme CSS from SCSS

gulp.task('customStyle', function(){

	var scssCustomStream = gulp.src([
    		paths.src.sass+'theme.scss'
        ])
	    .pipe(concat('theme.scss'))
	;

	var customMergedStream = merge(scssCustomStream)    
        .pipe(sass())
        //.pipe(cleanCSS())
        .pipe(size())
        .pipe(gulp.dest(paths.dist.css))
        .pipe(notify({message: 'TASK: "customStyle" Completed!', onLast: true }));
    return customMergedStream;
});



gulp.task( 'browserSync', function() {
    browserSync.init([paths.dist.css + '*.css',  paths.dist.root + '*.html'], {
        server: {
          baseDir: paths.dist.root
        }
    }); 
});


gulp.task('watch', function() {
    gulp.watch(paths.src.sass + '**/*.scss',['customStyle']);
    gulp.watch(paths.src.css + '**/*.css',['vendorStyle']);
    gulp.watch(paths.src.js + '**/*.js',['customJS']);
    gulp.watch(paths.src.js + '**/*.js',['vendorsJS']);
    gulp.watch(paths.src.jade + '**/*.pug',['jade']);
});


gulp.task('default', ['clean-js', 'clean-css', 'jade', 'customStyle', 'vendorStyle', 'vendorsJS', 'customJS', 'watch', 'browserSync']); 